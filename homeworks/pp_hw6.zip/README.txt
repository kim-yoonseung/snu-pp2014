# HOMEWORK 6 SELF-GRADING INSTRUCTION #


Principles of Programming (2014 Seoul National University)
TA Jeehoon Kang
TA Yoonseung Kim

Written by:

Principles of Programming (2013 Seoul National University)

TA Sungkeun Cho
TA Jeehoon Kang


## Self-grading your Racket submission ##

Grade like:

racket hw6-1-grade.rkt


## Self-grading your OCaml submission ##

Grade like:

ocamlc commonGrade.ml
ocamlc hw6_2.ml
ocaml commonGrade.cmo hw6_2.cmo hw6_2_grade.ml