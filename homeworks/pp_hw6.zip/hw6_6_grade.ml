open CommonGrade
open Hw6_6

let _ = output (fun () ->
  crazy2val (ONE (MONE NIL)) = (-1))

