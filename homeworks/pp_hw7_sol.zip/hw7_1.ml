(* TA's comment:
 * 1. Implement step_tm as well as run_tm.
 *
 * 2. Functions print_tape and print_tm has different type from the direction.
 * Follow the types in this skeleton code.
 *)

module type TM = sig
  type symbol = string
  type move = Right | Left | Stay
  type todo = Erase | Write of symbol
  type state = string
  type rule = state * symbol * todo * move * state
  type ruletable = rule list
  type tape
  type tm
  (* tape part *)
  val init_tape: symbol list -> tape
  val read_tape: tape -> symbol
  val write_tape: tape -> symbol -> tape
  val move_tape_left: tape -> tape
  val move_tape_right: tape -> tape
  val print_tape: tape -> int -> string (* instead of tape -> unit *)
  (* rule table part *)
  val match_rule: state -> symbol -> ruletable -> (todo * move * state) option
  (* instead of state -> symbol -> ruletable -> todo * move * state *)
  (* main *)
  val make_tm: symbol list -> state -> ruletable -> tm
  (* instead of symbol list -> state list -> state -> ruletable -> tm *)
  val step_tm: tm -> tm option (* You should implement this. *)
  val run_tm: tm -> tm
  val print_tm: tm -> int -> string (* instead of tm -> int -> unit *)
end

module TuringMachine  = struct (* : TM*)
  exception ETODO
  type tTODO = CTODO

  type symbol = string
  type move = Right | Left | Stay
  type todo = Erase | Write of symbol
  type state = string
  type rule = state * symbol * todo * move * state
  type ruletable = rule list

  type tape = (symbol list)*symbol*(symbol list) (* should be replaced *)
  type tm = tape * state * ruletable (* should be replaced *)

  (* tape part *)
  let init_tape: symbol list -> tape =
    fun symbols ->
			match symbols with
			| [] -> ([],"-",[])
			| h::t -> ([],h,t)
    
  let read_tape: tape -> symbol =
    fun tape ->
			match tape with
			| (a,b,c) -> b

  let write_tape: tape -> symbol -> tape =
    fun tape s ->
    	match tape with
			| (a,b,c) -> (a,s,c)
	
	let rec snoc l a =
		match l with
		| [] -> [a]
		| h::t -> h::(snoc t a)
	let rec brk l =
		match l with
		| [] -> ([],"-")
		| [s] -> ([],s)
		| h::t ->
			let (t1,t2) = brk t in
			(h::t1,t2)
							
							

  let move_tape_left: tape -> tape =
    fun tape ->
      match tape with
			| (a,b,c) ->
				let newa = snoc a b in
				(match c with
				| [] -> (newa,"-",[])
				| ch::ct -> (newa,ch,ct))

  let move_tape_right: tape -> tape =
    fun tape ->
    	match tape with
			| (a,b,c) ->
				let (a1,a2) = brk a in
				(a1,a2,b::c)
				
	let rec get_last symlist size =
		if (size = 0) then "" else
			let (s1,s2) = brk symlist in
			(get_last s1 (size-1))^s2^"."
			
	let rec get_first symlist size =
		if (size = 0) then "" else
			match symlist with
			| [] -> ".-"^(get_first [] (size-1))
			| h::t -> "."^h^(get_first t (size-1))
		 

  let print_tape: tape -> int -> string = (* instead of tape -> unit *)
    fun tape size ->
    	match tape with
			| (a,b,c) -> (get_last a size)^b^(get_first c size)

  (* rule table part *)
  let rec match_rule: state -> symbol -> ruletable -> (todo * move * state) option =
    fun st sym rules ->
    	match rules with
			| [] -> None
			| r::t ->
				match r with
				| (st1,sym1,td,mv,st2) -> (if (st = st1) && (sym = sym1) then Some (td,mv,st2) else
					match_rule st sym t)


  (* main *)
  let make_tm: symbol list -> state -> ruletable -> tm =
    (* instead of symbol list -> state list -> state -> ruletable -> tm *)
    fun symbols initial_state rules ->
      (init_tape symbols,initial_state,rules)

  let step_tm: tm -> tm option =
    fun tm ->
			match tm with
			| (tape,state,ruletable) ->
				let sym = read_tape tape in
				match match_rule state sym ruletable with
				| None -> None
				| Some (todo,move,st2) ->
					let tape1 =
						match todo with
						| Erase -> write_tape tape "-"
						| Write ns -> write_tape tape ns
					in
					let tape2 = 
						match move with
						| Right -> move_tape_left tape1
						| Left -> move_tape_right tape1
						| Stay -> tape1
					in
					Some (tape2,st2,ruletable)

  let rec run_tm: tm -> tm =
    fun tm ->
			match (step_tm tm) with
			| None -> tm
			| Some tm1 -> (run_tm tm1)

  let print_tm: tm -> int -> string = (* instead of tm -> int -> unit *)
    fun tm size ->
    	match tm with
			| (tape,_,_) -> print_tape tape size
end
