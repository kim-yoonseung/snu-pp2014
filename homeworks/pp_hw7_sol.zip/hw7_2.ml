module type SKI = sig
  type liquid =
    | S
    | K
    | I
    | V of string (* varible *)
    | M of liquid * liquid (* mix of two liquids *)
  val react: liquid -> liquid
  val pprint: liquid -> string
end

module SkiLiquid : SKI = struct
  exception ETODO

  type liquid =
    | S
    | K
    | I
    | V of string (* varible *)
    | M of liquid * liquid (* mix of two liquids *)

  let rec react: liquid -> liquid =
    fun l ->
			match l with
			| M (l1, l2) ->
				(match (react l1) with
				| I -> react l2
				| M (K,e) -> react e
				| M (M (S,e1), e2) -> react (M(M(e1,l2),M(e2,l2)))
				| e -> M (e, react l2))
			| _ -> l
			
  let rec pprint: liquid -> string =
    fun l ->
			match l with
			| S -> "S"
			| K -> "K"
			| I -> "I"
			| V (s) -> s
			| M (l1,l2) -> "(" ^ (pprint l1) ^ " " ^ (pprint l2) ^ ")"
end
