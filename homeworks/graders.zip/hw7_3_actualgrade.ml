open CommonGrade
open Hw7_3

let cases = [
  (true, "11",
   (Smatch.Mult
      (Smatch.Mult (Smatch.One,Smatch.Star Smatch.Zero),
       Smatch.Opt Smatch.One)));
  (false, "11",
   (Smatch.Mult
      (Smatch.Star (Smatch.Mult (Smatch.One,Smatch.Zero)),
       Smatch.One)));
  (true, "",
   (Smatch.Opt (Smatch.Star Smatch.One)));
  (false, "101010101010101010101010101010101010102",
   (Smatch.Mult
      (Smatch.One,
       (Smatch.Mult
          (Smatch.Star (Smatch.Mult (Smatch.Zero, Smatch.One)),
           Smatch.Zero)))));
  (true, "012012012012012210210210012210012210012210012210",
   (Smatch.Star
      (Smatch.Sum
         (Smatch.Mult
            (Smatch.Mult
               (Smatch.Zero,
                Smatch.One),
             Smatch.Two),
          (Smatch.Mult
             (Smatch.Mult
                (Smatch.Two,
                 Smatch.One),
              Smatch.Zero))))));
]

let _ =
  List.iter
    (fun (a, s, c) ->
     output (fun () -> (Smatch.smatch s c) = a))
    cases
