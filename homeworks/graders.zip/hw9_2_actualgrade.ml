open CommonGrade
open Hw9_2

let rec matrix2list_get_row 
    (r:int) (c:int) (col_size:int) (m:Markov.matrix)
    : float list = 
  if c >= col_size
  then []
  else 
    (Markov.ij m c r)::
      (matrix2list_get_row r (c+1) col_size m)

let rec matrix2list_row 
    (r:int) (col_size:int) (row_size:int) (m:Markov.matrix)  
    : float list list = 
  if r >= row_size
  then []
  else 
    (matrix2list_get_row r 0 col_size m)::
      (matrix2list_row (r+1) col_size row_size m)

let matrix2list (m:Markov.matrix) : float list list =
  let (col_size,row_size) = Markov.size m in
  matrix2list_row 0 col_size row_size m

let rec list2matrix_rec (l:float list list) (m:Markov.matrix)
    : Markov.matrix = 
  match l with
  | [] -> m
  | hd::tl -> list2matrix_rec tl (Markov.add_row hd m)

let list2matrix (l:float list list) : Markov.matrix = 
  match l with
  | [] -> invalid_arg "list2matrix"
  | hd::tl -> list2matrix_rec tl (Markov.row hd)

let rec mul_sum (m1:float list) (m2:float list) : float =
  match m1,m2 with
  | hd1::tl1,hd2::tl2 -> (hd1*.hd2) +. (mul_sum tl1 tl2)
  | _,_ -> 0.0

let rec mul_list_col (m1:float list) (m2:float list list) 
    : float list =
  if List.length (List.hd m2) <= 0
  then []
  else 
    (mul_sum m1 (List.map List.hd m2))::
      (mul_list_col m1 (List.map List.tl m2))

let rec mul_list 
    (m1:float list list) (m2:float list list)
    : float list list =
  match m1 with
  | [] -> []
  | hd::tl -> (mul_list_col hd m2)::(mul_list tl m2)

let mul (m1:Markov.matrix) (m2:Markov.matrix) : Markov.matrix =
  let m1_list = matrix2list m1 in
  let m2_list = matrix2list m2 in
  let m3_list = mul_list m1_list m2_list in
  list2matrix m3_list

let error : float = 0.0001

let rec same_rec (r:int) (c:int) (m1:Markov.matrix) (m2:Markov.matrix)
    : bool = 
  let (c_size,r_size) = Markov.size m1 in
  if r >= r_size
  then true
  else if c >= c_size
  then same_rec (r+1) 0 m1 m2
  else (Markov.ij m1 c r -. Markov.ij m2 c r < error)&&
    (same_rec r (c+1) m1 m2)

let same (m1:Markov.matrix) (m2:Markov.matrix) : bool = 
  same_rec 0 0 m1 m2

let rec sum (m:float list) : float = 
  match m with
  | [] -> 0.
  | hd::tl -> hd +. (sum tl)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [1./.3.;1./.3.;1./.3.] 
           (Markov.column [1./.2.;1./.2.;0.]))
      in
      let minit = Markov.column [1./.3.;1./.3.;1./.3.] in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [1.;0.;0.] 
        (Markov.add_column [0.;0.;1.] 
           (Markov.column [0.;1./.2.;1./.2.]))
      in
      let minit = Markov.column [1./.3.;1./.3.;1./.3.] in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [1./.3.;1./.3.;0.;1./.3.] 
        (Markov.add_column [1./.3.;1./.3.;0.;1./.3.] 
           (Markov.add_column [1./.3.;1./.3.;0.;1./.3.] 
              (Markov.column [0.;1./.2.;1./.2.;0.])))
      in
      let minit = (Markov.column [1./.4.;1./.4.;1./.4.;1./.4.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [1./.5.;1./.5.;1./.5.;1./.5.;1./.5.] 
        (Markov.add_column [0.;0.;0.;1./.2.;1./.2.] 
           (Markov.add_column [0.;1./.2.;0.;0.;1./.2.] 
              (Markov.add_column [1./.2.;0.;0.;0.;1./.2.] 
                 (Markov.column [0.;0.;1./.2.;0.;1./.2.]))))
      in
      let minit = (Markov.column [1./.5.;1./.5.;1./.5.;1./.5.;1./.5.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [0.;0.;1.] 
           (Markov.column [1./.3.;1./.3.;1./.3.]))
      in
      let minit = (Markov.column [1./.3.;1./.3.;1./.3.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [1./.4.;1./.4.;1./.4.;1./.4.] 
        (Markov.add_column [0.;1.;0.;0.] 
           (Markov.add_column [1.;0.;0.;0.] 
              (Markov.column [0.;0.;1.;0.])))
      in
      let minit = (Markov.column [1./.4.;1./.4.;1./.4.;1./.4.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [1./.2.;0.;1./.2.] 
           (Markov.column [0.;1.;0.]))
      in
      let minit = (Markov.column [1./.3.;1./.3.;1./.3.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [1.;0.;0.] 
           (Markov.column [0.;0.;1.]))
      in
      let minit = (Markov.column [1./.3.;1./.3.;1./.3.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [0.;0.;1.] 
           (Markov.column [0.;0.;1.]))
      in
      let minit = (Markov.column [1./.3.;1./.3.;1./.3.]) in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)

let _ =
  output
    (fun () ->
      let mat = Markov.add_column [0.;1.;0.] 
        (Markov.add_column [1./.2.;0.;1./.2.] 
           (Markov.column [0.;1.;0.]))
      in
      let minit = Markov.column [1./.3.;1./.3.;1./.3.] in
      let result1 = Markov.markov_limit mat minit in
      let result2 = mul mat result1 in
      same result1 result2 && 
        sum (List.map List.hd (matrix2list result1)) -. 1. < error)
