exception TODO

 type ae =
  | CONST of int
  | VAR of string
  | POWER of string * int
  | TIMES of ae list
  | SUM of ae list

(*
let rec diff_sum (l : ae list) (x: string) : ae list =
	match l with
	| [] -> []
	| h :: t -> (diff h x) :: (diff_sum t x)
*)
let rec diff (e: ae) (x: string): ae =
	let rec diff_sum (l : ae list) (x: string) : ae list =
		match l with
		| [] -> []
		| h :: t -> (diff h x) :: (diff_sum t x)
	in
  match e with
  | CONST _ -> CONST 0
  | VAR z -> (if (x = z) then (CONST 1) else (CONST 0))
  | POWER (z,p) ->(if (x = z) then (TIMES [CONST p;POWER (z,p-1)]) else (CONST 0))
  | TIMES ael ->
		(match ael with
    | [] -> CONST 0
    | h :: t -> (SUM [(TIMES ((diff h x)::t)) ; (TIMES [h;(diff (TIMES t) x)])])
		)
  | SUM ael ->
		SUM (diff_sum ael x)