exception TODO

type crazy2 =
  | NIL
  | ZERO of crazy2
  | ONE of crazy2
  | MONE of crazy2

let crazy2toint (c:crazy2) : int =
	match c with
	| ONE NIL -> 1
	| MONE NIL -> -1
	| _ -> 0

let crazy2pair (c:crazy2) : (int * crazy2) =
	match c with
	| NIL -> (0,NIL)
	| ZERO c1 -> (0,c1)
	| ONE c1 -> (1,c1)
	| MONE c1 -> (-1,c1)

let carry2crazy (c:int) : crazy2 =
	match c with
	| -1 -> MONE NIL
	| 0 -> ZERO NIL
	| _ -> ONE NIL

let rec crazy2addc a b ca : crazy2 =
	let intf (n:int) (c1:crazy2) (c2:crazy2) : crazy2 =
		match n with
		| 3 -> ONE (crazy2addc c1 c2 1)
		| 2 -> ZERO (crazy2addc c1 c2 1)
		| 1 -> ONE (crazy2addc c1 c2 0)
		| 0 -> ZERO (crazy2addc c1 c2 0)
		| -1 -> MONE (crazy2addc c1 c2 0)
		| -2 -> ZERO (crazy2addc c1 c2 (-1))
		| -3 -> MONE (crazy2addc c1 c2 (-1))
		| _ -> NIL
	in
	match (a,b) with
	| (NIL,NIL) -> carry2crazy ca
	| (_,_) ->
		let (an,ac) = crazy2pair a in
		let (bn,bc) = crazy2pair b in
		intf (an+bn+ca) ac bc
	
	
	
(*	
	match (a,b,cr) with
	| (ONE a1, ONE b1, 1) -> ONE (crazy2addc a1 b1 1)
	| (ONE a1, ONE b1, 0) | (ONE a1, ZERO b1, 1) | (ZERO a1, ONE b1, 1)  -> ZERO (crazy2addc a1 b1 1)
	| (ONE a1, ONE b1, -1) | (ONE a1, MONE b1, 1) | (MONE a1, ONE b1, 1)
	| (ONE a1, ZERO b1, 0) | (ZERO a1, ONE b1, 0) | (ZERO a1, ZERO b1, 1) -> ONE (crazy2addc a1 b1 0)
	| (ONE a1, ZERO b1, -1) | (ONE a1, MONE b1, 
	
	| (ONE a1, ZERO b1, 1) -> ZERO (crazy2addc a1 b1 1)
	| (ONE a1, ZERO b1, 0) -> ONE (crazy2addc a1 b1 0)
	| (ONE a1, ZERO b1, -1) -> ZERO (crazy2addc a1 b1 0)

	| (ZERO a1, ONE b1, 1) -> ZERO (crazy2addc a1 b1 1)
	| (ZERO a1, ONE b1, 0) -> ONE (crazy2addc a1 b1 0)
	| (ZERO a1, ONE b1, -1) -> ZERO (crazy2addc a1 b1 0)
	
	| (ZERO a1, ZERO b1, 1) -> ONE (crazy2addc a1 b1 0)
	| (ZERO a1, ZERO b1, 0) -> ZERO (crazy2addc a1 b1 0)
	| (ZERO a1, ZERO b1, -1) -> MONE (crazy2addc a1 b1 0)

	| (ONE a1, MONE b1, 1) -> ONE (crazy2addc a1 b1 0)
	| (ONE a1, MONE b1, 0) -> ZERO (crazy2addc a1 b1 0)
	| (ONE a1, MONE b1, -1) -> ZERO (crazy2addc a1 b1 -1)

	| (MONE a1, ONE b1, 1) -> ONE (crazy2addc a1 b1 0)
	| (MONE a1, ONE b1, 0) -> ZERO (crazy2addc a1 b1 0)
	| (MONE a1, ONE b1, -1) -> ONE (crazy2addc a1 b1 -1)
	 
*)	

let rec crazy2add (a: crazy2) (b: crazy2): crazy2 =
  crazy2addc a b 0

