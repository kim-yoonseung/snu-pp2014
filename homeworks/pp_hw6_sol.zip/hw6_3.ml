exception TODO

type team = Korea | France | Usa | Brazil | Japan | Nigeria | Cameroon
          | Poland | Portugal | Italy | Germany | Norway | Sweden | England
          | Argentina

type tourna = LEAF of team
            | NODE of tourna * tourna

type opt_tourna = NONE | SOME of tourna

let team_tostring t =
  match t with
  | Korea -> "Korea"
  | France -> "France"
  | Usa -> "Usa"
	| Brazil -> "Brazil"
	| Japan -> "Japan"
	| Nigeria -> "Nigeria"
	| Cameroon -> "Cameroon"
	| Poland -> "Poland"
	| Portugal ->"Portugal"
	| Italy -> "Italy"
	| Germany -> "Germany"
	| Norway -> "Norway"
	| Sweden -> "Sweden"
	| England -> "England"
	| Argentina -> "Argentina"

let rec parenize (t: tourna): string =
  match t with
  | LEAF tm -> team_tostring tm
  | NODE (t1, t2) -> String.concat "" ["("; parenize t1;" "; parenize t2; ")"]

let rec drop_t (t:tourna) (d:team) : opt_tourna =
	match t with
	| LEAF tm -> if (tm = d) then NONE else (SOME t)
	| NODE (t1, t2) ->
		match (drop_t t1 d, drop_t t2 d) with
		| (NONE,NONE) -> NONE
		| (NONE, SOME rt2) -> (SOME rt2)
		| (SOME rt1, NONE) -> (SOME rt1)
		| (SOME rt1, SOME rt2) -> SOME (NODE (rt1, rt2))  

let rec drop (t: tourna) (d: team): string =
	match (drop_t t d) with
	| NONE -> ""
	| SOME rt -> parenize rt
	
(*  match t with
  | LEAF tm ->
    if (d = tm) then "" else (team_tostring tm)
  | NODE (t1, t2) ->
    match (drop t1 d, drop t2 d) with
    | "", s -> s
    | s, "" -> s
    | s1, s2 -> "(" + s1 + " " + s2 + ")"
		*)
